API_ID = 12345678  # Reemplazar con tu API_ID de my.telegram.org
API_HASH = "tu_api_hash"  # Reemplazar con tu API_HASH
BOT_TOKEN = "tu_bot_token"  # Token del bot
CANAL_USERNAME = "@tu_canal"  # Username del canal
CANAL_URL = "https://t.me/tu_canal"  # Link al canal para mostrar